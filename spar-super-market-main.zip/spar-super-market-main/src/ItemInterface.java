public interface ItemInterface {
    double calculateTotalPrice();
    String getName();
    int getQuantity();
    void setQuantity(int quantity);
    double getUnitPrice();
}
